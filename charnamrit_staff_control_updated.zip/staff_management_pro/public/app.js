let state={user:null,csrf:null,staff:[]};
const $=id=>document.getElementById(id);
async function api(url,opts={}){const o={...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}};if(!['GET','HEAD'].includes((o.method||'GET').toUpperCase()))o.headers['x-csrf-token']=state.csrf;const r=await fetch(url,o);const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Error');return d}
async function boot(){try{const d=await api('/api/me');state.user=d.user;state.csrf=d.csrfToken;showApp();}catch{showLogin()}}
function showLogin(){$('login').classList.remove('hidden');$('app').classList.add('hidden')}
function showApp(){$('login').classList.add('hidden');$('app').classList.remove('hidden');$('roleBadge').textContent=state.user.role;document.querySelectorAll('[data-admin]').forEach(x=>x.style.display=state.user.role==='ADMIN'?'block':'none');load('dashboard')}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginMsg').textContent='';try{const d=await api('/api/login',{method:'POST',body:JSON.stringify({email:$('email').value,password:$('password').value})});state.user=d.user;state.csrf=d.csrfToken;showApp()}catch(e){$('loginMsg').textContent=e.message}})
$('logout').onclick=async()=>{try{await api('/api/logout',{method:'POST'})}finally{location.reload()}}
document.querySelectorAll('aside button').forEach(b=>b.onclick=()=>{document.querySelectorAll('aside button').forEach(x=>x.classList.remove('active'));b.classList.add('active');load(b.dataset.page)})
async function load(page){
  const c=$('content');
  try{
    if(page==='dashboard'){
      const d=await api('/api/dashboard');
      const cards=d.role==='ADMIN'
        ? [['Active Staff',d.active_staff],['Today Present',d.today_present],['Pending Advance',d.pending_advances],['Advance Total','₹'+Number(d.advance_total).toLocaleString('en-IN')]]
        : d.role==='MANAGER'
        ? [['Active Staff',d.active_staff],['Today Present',d.today_present],['My Pending Advance',d.my_pending_advances],['Access','Attendance + Request']]
        : [['Salary','₹'+Number(d.salary).toLocaleString('en-IN')],['Advance Taken','₹'+Number(d.advance_total).toLocaleString('en-IN')],['Present (30 days)',d.last30_present],['Access','My Attendance + Advance']];
      c.innerHTML=`<h2>Dashboard</h2><div class="grid">${cards.map(x=>`<div class="card stat"><span>${esc(x[0])}</span><strong>${esc(x[1])}</strong></div>`).join('')}</div><div class="panel lock-note">🔒 Manager की पिछली तारीख की attendance backend पर भी locked है। केवल Admin correction कर सकता है।</div>`;
    }
    if(page==='attendance') await attendance(c);
    if(page==='advance') await advance(c);
    if(page==='staff') await staff(c);
    if(page==='ledger') await ledger(c);
    if(page==='audit') await audit(c);
  }catch(e){c.innerHTML=`<div class="panel error">${esc(e.message)}</div>`}
}
async function getStaff(){state.staff=await api('/api/staff');return state.staff}
async function attendance(c){
  const list=await api('/api/attendance'); if(!state.staff.length && state.user.role!=='STAFF')await getStaff();
  const isManager=state.user.role==='MANAGER', today=new Date().toISOString().slice(0,10);
  c.innerHTML=`<h2>Attendance</h2>${state.user.role!=='STAFF'?`<div class="panel"><h3>Attendance Mark करें</h3><div class="row">
  <label>Staff<select id="astaff">${state.staff.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></label>
  <label>Date<input id="adate" type="date" value="${today}" ${isManager?'min="'+today+'" max="'+today+'"':''}></label>
  <label>Status<select id="astatus"><option value="PRESENT">Present</option><option value="ABSENT">Absent</option><option value="LEAVE">Leave</option><option value="HALF_DAY">Half Day</option></select></label>
  <label>In<input id="ain" type="time"></label><label>Out<input id="aout" type="time"></label>
  <label>Overtime (min)<input id="aot" type="number" min="0" value="0"></label><button id="saveA">Save Attendance</button></div>${isManager?'<div class="lock-note">Manager केवल आज की attendance mark/change कर सकता है। कल की attendance अपने-आप locked रहेगी।</div>':''}</div>`:''}
  <div class="panel table-wrap"><table><thead><tr><th>Date</th><th>Staff</th><th>Status</th><th>In</th><th>Out</th><th>OT</th><th>Marked</th></tr></thead><tbody>${list.map(a=>`<tr><td>${a.attendance_date}</td><td>${esc(a.name)}</td><td><span class="pill">${a.status}</span></td><td>${a.check_in||'-'}</td><td>${a.check_out||'-'}</td><td>${a.overtime_minutes}</td><td>${a.marked_by}</td></tr>`).join('')}</tbody></table></div>`;
  $('saveA')?.addEventListener('click',async()=>{try{await api('/api/attendance',{method:'POST',body:JSON.stringify({staff_id:$('astaff').value,attendance_date:$('adate').value,status:$('astatus').value,check_in:$('ain').value||null,check_out:$('aout').value||null,overtime_minutes:Number($('aot').value||0)})});load('attendance')}catch(e){alert(e.message)}})
}
async function advance(c){
  if(state.user.role==='ADMIN'){
    c.innerHTML=`<h2>Advance</h2><div class="panel"><h3>Admin Approval</h3><div id="requests">Loading...</div></div>`;
    const r=await api('/api/advance-requests');$('requests').innerHTML=`<div class="table-wrap"><table><thead><tr><th>Staff</th><th>Amount</th><th>Reason</th><th>Requested By</th><th>Status</th><th>Action</th></tr></thead><tbody>${r.map(x=>`<tr><td>${esc(x.staff_name)}</td><td>₹${x.amount}</td><td>${esc(x.reason)}</td><td>${esc(x.requested_by_name)}</td><td>${x.status}</td><td>${x.status==='PENDING'?`<button onclick="decide('${x.id}','APPROVED')">Approve</button> <button onclick="decide('${x.id}','REJECTED')">Reject</button>`:'-'}</td></tr>`).join('')}</tbody></table></div>`;
    return;
  }
  if(state.user.role==='STAFF'){
    const f=await api('/api/my-finance'), r=await api('/api/my-advance-requests');
    c.innerHTML=`<h2>Advance</h2><div class="panel"><h3>Advance Request</h3><div class="row"><label>Amount<input id="ramt" type="number" min="1"></label><label>Reason<textarea id="rreason"></textarea></label><button id="sendR">Request भेजें</button></div></div><div class="panel table-wrap"><h3>My Requests</h3><table><thead><tr><th>Date</th><th>Amount</th><th>Reason</th><th>Status</th><th>Admin Note</th></tr></thead><tbody>${r.map(x=>`<tr><td>${new Date(x.created_at).toLocaleDateString('en-IN')}</td><td>₹${x.amount}</td><td>${esc(x.reason)}</td><td>${x.status}</td><td>${esc(x.admin_note||'-')}</td></tr>`).join('')}</tbody></table></div>`;
    $('sendR').onclick=async()=>{try{await api('/api/advance-requests',{method:'POST',body:JSON.stringify({staff_id:f.id,amount:Number($('ramt').value),reason:$('rreason').value})});alert('Request Admin को भेज दिया गया');load('advance')}catch(e){alert(e.message)}};
    return;
  }
  await getStaff();
  c.innerHTML=`<h2>Advance</h2><div class="panel"><h3>Staff Advance Request</h3><div class="row"><label>Staff<select id="rstaff">${state.staff.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></label><label>Amount<input id="ramt" type="number" min="1"></label><label>Reason<textarea id="rreason"></textarea></label><button id="sendR">Request भेजें</button></div><div class="lock-note">Manager केवल request भेज सकता है। Approve/Reject और ledger का control Admin के पास रहेगा।</div></div>`;
  $('sendR').onclick=async()=>{try{await api('/api/advance-requests',{method:'POST',body:JSON.stringify({staff_id:$('rstaff').value,amount:Number($('ramt').value),reason:$('rreason').value})});alert('Request Admin को भेज दिया गया');$('ramt').value='';$('rreason').value=''}catch(e){alert(e.message)}}
}
async function decide(id,status){try{await api('/api/advance-requests/'+id,{method:'PATCH',body:JSON.stringify({status})});load('advance')}catch(e){alert(e.message)}}
async function staff(c){const s=await getStaff();c.innerHTML=`<h2>Staff</h2><div class="panel"><h3>New Staff</h3><div class="row"><label>Name<input id="sn"></label><label>Email<input id="se" type="email"></label><label>Phone<input id="sp"></label><label>Department<input id="sd"></label><label>Salary<input id="ss" type="number" min="0"></label><label>Joining Date<input id="sj" type="date"></label><label>Login Password<input id="sx" type="password" minlength="10"></label><button id="addS">Add Staff</button></div></div><div class="panel table-wrap"><table><thead><tr><th>Name</th><th>Phone</th><th>Department</th><th>Salary</th><th>Active</th></tr></thead><tbody>${s.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||'-')}</td><td>${esc(x.department||'-')}</td><td>₹${x.salary}</td><td>${x.active?'Yes':'No'}</td></tr>`).join('')}</tbody></table></div>`;$('addS').onclick=async()=>{try{await api('/api/admin/staff',{method:'POST',body:JSON.stringify({name:$('sn').value,email:$('se').value,phone:$('sp').value,department:$('sd').value,salary:Number($('ss').value||0),joining_date:$('sj').value||null,password:$('sx').value})});load('staff')}catch(e){alert(e.message)}}}
async function ledger(c){const l=await api('/api/admin/ledger');c.innerHTML=`<h2>Advance Ledger</h2><div class="panel table-wrap"><table><thead><tr><th>Date</th><th>Staff</th><th>Amount</th><th>Type</th><th>Created By</th></tr></thead><tbody>${l.map(x=>`<tr><td>${new Date(x.created_at).toLocaleString()}</td><td>${esc(x.staff_name)}</td><td>₹${x.amount}</td><td>${x.entry_type}</td><td>${x.created_by}</td></tr>`).join('')}</tbody></table></div>`}
async function audit(c){const a=await api('/api/audit');c.innerHTML=`<h2>Security History</h2><div class="panel table-wrap"><table><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead><tbody>${a.map(x=>`<tr><td>${new Date(x.created_at).toLocaleString()}</td><td>${esc(x.actor_name||'-')}</td><td>${x.action}</td><td>${x.entity_type}</td><td>${esc(JSON.stringify(x.details||{}))}</td></tr>`).join('')}</tbody></table></div>`}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
boot();
