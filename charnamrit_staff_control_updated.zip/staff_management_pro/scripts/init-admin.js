require('dotenv').config();
const { Pool } = require('pg');
const crypto = require('crypto');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

(async () => {
  const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  if (!ADMIN_NAME || !ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.includes('CHANGE')) {
    throw new Error('Set ADMIN_NAME, ADMIN_EMAIL and a strong ADMIN_PASSWORD in .env before starting.');
  }
  const exists = await pool.query('SELECT id FROM users WHERE email=$1', [ADMIN_EMAIL.toLowerCase()]);
  if (!exists.rowCount) {
    await pool.query(
      'INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4)',
      [ADMIN_NAME, ADMIN_EMAIL.toLowerCase(), hashPassword(ADMIN_PASSWORD), 'ADMIN']
    );
    console.log('Initial Admin created.');
  } else {
    console.log('Admin already exists; no password changed.');
  }
  await pool.end();
})().catch(async e => { console.error(e.message); await pool.end(); process.exit(1); });
